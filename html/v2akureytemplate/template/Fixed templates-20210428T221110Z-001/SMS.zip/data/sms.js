const jsonData = `{
    "Name" : "Nahomy Chavarria",
    "PhoneNumber": "+506 87766888",
    "Date": "12/04/2020",
    "Hour": "12:34",
    "SMSText": " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed auctor sit amet massa quis hendrerit. Vivamus sit amet vulputate neque. Phasellus nisl sapien, rutrum eget interdum malesuada, semper rutrum metus. Suspendisse sapien ipsum, ornare id faucibus sit amet, consequat scelerisque lectus. Etiam tincidunt sodales mauris, imperdiet dapibus lorem sagittis ut. Aenean elementum, magna in hendrerit eleifend, magna neque scelerisque augue, ut porttitor est dolor nec nisi. Curabitur lorem urna, mattis quis cursus vitae, volutpat pulvinar mi. Phasellus ultrices, nulla a hendrerit molestie, sapien ipsum luctus tellus, ut placerat tortor leo luctus justo. Suspendisse rhoncus ante in purus lacinia, eu fermentum dolor imperdiet. Praesent vitae condimentum turpis, sit amet commodo turpis. Suspendisse convallis malesuada nunc. Cras sed imperdiet ante."}`;

    const overlayMessages = `{
        "Name" : "",
        "PhoneNumber": "number",
        "SMS": "Message"
    }`;