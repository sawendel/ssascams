
const gophishPort = 3333;
const gophishAPIKey = "1511b4aa4dfcf489f1f9f7fa9c62eda74911c62f9d3a1df8a00612aae2437ddd";
const mailDomain = "behavioralsurvey.com";
const generalEmailPassword = "Password1234*";


const ec2Host = "3.20.89.142";
const DBPort = 3306;
const DBUser = "testaws";
const DBPassword = "pass1234";
const DBtoConnect = "vmail";

const mailClientBaseURL = ec2Host.concat(":7000");



exports.ec2Host = ec2Host;
exports.DBPort = DBPort;
exports.DBUser = DBUser;
exports.DBPassword = DBPassword;
exports.DBtoConnect = DBtoConnect;

exports.mailClientBaseURL = mailClientBaseURL;
exports.generalEmailPassword = generalEmailPassword;
exports.mailDomain = mailDomain;
exports.gophishPort = gophishPort;
exports.gophishAPIKey = gophishAPIKey;