const baseGophishURL = "3.20.89.142";
const gophishPort = 3333;
const gophishAPIKey = "1511b4aa4dfcf489f1f9f7fa9c62eda74911c62f9d3a1df8a00612aae2437ddd";
const mailDomain = "behavioralsurvey.com";
const mailClientBaseURL = "3.20.89.142:7000";
const generalEmailPassword = "Password1234*";

exports.mailClientBaseURL = mailClientBaseURL;
exports.generalEmailPassword = generalEmailPassword;
exports.mailDomain = mailDomain;
exports.baseGophishURL = baseGophishURL;
exports.gophishPort = gophishPort;
exports.gophishAPIKey = gophishAPIKey;