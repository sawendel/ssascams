
const gophishPort = 3333;
const gophishAPIKey = "bca4b0217e5668979d685720028c6675ee62105683c0b9f010bf8084aa2d1eab";
const mailDomain = "behavioralsurvey.com";
const generalEmailPassword = "Password1234*";


const ec2Host = "3.20.89.142";
const DBPort = 3306;
const DBUser = "testaws";
const DBPassword = "pass1234";
const DBtoConnect = "vmail";

const mailClientBaseURL = ec2Host.concat(":7000");



exports.ec2Host = ec2Host;
exports.DBPort = DBPort;
exports.DBUser = DBUser;
exports.DBPassword = DBPassword;
exports.DBtoConnect = DBtoConnect;

exports.mailClientBaseURL = mailClientBaseURL;
exports.generalEmailPassword = generalEmailPassword;
exports.mailDomain = mailDomain;
exports.gophishPort = gophishPort;
exports.gophishAPIKey = gophishAPIKey;