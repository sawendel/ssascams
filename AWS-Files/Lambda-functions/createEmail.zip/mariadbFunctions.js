const mariadb = require('mariadb');
const env = require("./env.js");


const pool = mariadb.createPool({host: env.ec2Host, user: env.DBUser, password: env.DBPassword, port:env.DBPort, database: env.DBtoConnect, connectionLimit: 5});

async function addEmailToMailServer(email, emailData) {
  var name = " "
  if(emailData.hasOwnProperty("firstName")){
        name = emailData.firstName;
  }else{
    name = emailData.userId;
  }
  let conn;
  var result = 0;
  try {
	  conn = await pool.getConnection();
	  
	 await conn.query(`CALL sscams_registermailbox("${email}","${name}");`);
  } catch (err) {
	throw err;
  } finally {
	if (conn) conn.release(); //release to pool
  }
}
async function getCampaignIDs(gophishGroupName) {

  let conn;
  var result = 0;
  var query = `SELECT campaignid from groups_per_campaign where groupname = "${gophishGroupName}"`;
  console.log(query);
  try {
	  conn = await pool.getConnection();
	  
	 await conn.query(query).then((rows)=>{
	   return rows;
	 });
  } catch (err) {
	throw err;
  } finally {
	if (conn) conn.release(); //release to pool
  }
}


exports.getCampaignIDs = getCampaignIDs;
exports.addEmailToMailServer = addEmailToMailServer;