const mariadb = require('mariadb');
const pool = mariadb.createPool({host: "3.20.89.142", user: "testaws", password: "pass1234", port:3306, database: "vmail", connectionLimit: 5});

async function addEmailToMailServer(email, emailData) {
  var name = " "
  if(emailData.hasOwnProperty("firstName")){
        name = emailData.firstName;
  }else{
    name = emailData.userId;
  }
  let conn;
  var result = 0;
  try {
	  conn = await pool.getConnection();
	  
	 await conn.query(`CALL sscams_registermailbox("${email}","${name}");`);
  } catch (err) {
	throw err;
  } finally {
	if (conn) conn.release(); //release to pool
  }
}
async function getCampaignIDs(gophishGroupName) {

  let conn;
  var result = 0;
  var query = `SELECT campaignid from groups_per_campaign where groupname = "${gophishGroupName}"`;
  console.log(query);
  try {
	  conn = await pool.getConnection();
	  
	 await conn.query(query).then((rows)=>{
	   return rows;
	 });
  } catch (err) {
	throw err;
  } finally {
	if (conn) conn.release(); //release to pool
  }
}


exports.getCampaignIDs = getCampaignIDs;
exports.addEmailToMailServer = addEmailToMailServer;