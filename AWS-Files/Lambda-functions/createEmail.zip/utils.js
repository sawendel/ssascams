const Ajv = require('ajv');
const ajv = new Ajv.default({ allErrors: true });
const https = require('https');
const env = require("./env.js");


function schemaValidator(schema, data) {
  const validate = ajv.compile(schema);
  const validateData = validate(data);
  if (validateData) {
    return true;
  }
  console.log(validate.errors);
  return false;
}

function getServerDate(){
  var date = new Date();
  return date;
}

function generateEmailName(username){
  return username.concat("@",env.mailDomain)
}

function generateMailClientURL(mail){
  let encodedmail = Buffer.from(mail).toString('base64');
  let encodedpass = Buffer.from(env.generalEmailPassword).toString('base64');
  return env.mailClientBaseURL.concat("?email=",encodedmail,"&pass=", encodedpass);
}

async function saveToDB(emailData, email, link){
  
  var AWS = require('aws-sdk');
  var ddb = new AWS.DynamoDB({region: 'us-east-2'}); 
  var serverDate = getServerDate().toString();
  var params = {
    TableName: 'Emails',
    Item: {
      'USER_ID' : {S: emailData.userId},
      'GOPHISH_GROUP_NAME' : {S: emailData.gophishGroupName} ,
      'POSTTIME' : {S: serverDate},
      'INTERVENTION_ID' : {S: emailData.interventionId},
      'RESEARCH_NAME' : {S: emailData.researchName},
      'RESEARCHER_NAME' : {S: emailData.researcherName},
      'EMAIL': {S: email},
      'LOGIN_LINK': {S: link}
      }
    };
    
    if(emailData.hasOwnProperty("firstName")){
        params.Item.FIRST_NAME = {S: emailData.firstName};
    }
    if(emailData.hasOwnProperty("lastName")){
        params.Item.LAST_NAME = {S: emailData.lastName};
    }
    
  return new Promise((resolve, reject) => {
        ddb.putItem(params, function(err, data) {
        if (err) {
          reject(err);
        } else {
          resolve (true);
        }
      });
    });
}



async function getgophishGroups(){
  const options = {
    hostname: env.ec2Host,
    port: env.gophishPort,
    path: '/api/groups/',
    rejectUnauthorized: false,
    headers: {
        Authorization: env.gophishAPIKey
    }
};
  return new Promise((resolve, reject)=>{
    https.get(options, function(res){
      var result = "";
      res.on('data', (chunk) => {
        result+= chunk;
      });
      res.on('end', () =>{
        resolve(JSON.parse(result));
      })
      res.on('error', (err) =>{
        reject(err);
      })
    })
    
  })
}
async function getGophishGroup(GroupName){
  console.log("estoy en getgphish")
  var groups = await getgophishGroups();
  for (var i = 0; i < groups.length; i++) {
  if(groups[i].name === GroupName){
    return groups[i];
  }
}
  
  return null;
}

async function getGophishPayload(bodyData, email){
  var group = await getGophishGroup(bodyData.gophishGroupName);
  var first_Name = bodyData.userId;
  var last_Name = bodyData.userId;
  if(bodyData.hasOwnProperty("firstName")){
        first_Name = bodyData.firstName;
    }
  if(bodyData.hasOwnProperty("lastName")){
        last_Name = bodyData.lastName;
    }
  var newUser = {
            "email": email,
            "first_name": first_Name,
            "last_name": last_Name,
            "position": "User"
        };
  group.targets.push(newUser);
  delete group["modified_date"];
  return group;
}



async function addUserToGophishGroup(bodyData, email){
  var payload = await getGophishPayload(bodyData, email);
  const options = {
    hostname: env.ec2Host,
    port: env.gophishPort,
    path: `/api/groups/${payload.id.toString()}`,
    rejectUnauthorized: false,
    method: 'PUT',
    headers: {
        Authorization: env.gophishAPIKey
    }
}
  return new Promise((resolve, reject)=>{
    var req = https.request(options, function(res){
      var result = "";
      res.on('data', (chunk) => {
        result+= chunk;
      });
      res.on('end', () =>{
        resolve(JSON.parse(result));
      })
      res.on('error', (err) =>{
        reject(err);
      })
      
    });
    req.write(JSON.stringify(payload));
    req.end();
  })
}




exports.generateMailClientURL = generateMailClientURL;
exports.addUserToGophishGroup = addUserToGophishGroup;
exports.generateEmailName = generateEmailName
exports.getServerDate = getServerDate;
exports.schemaValidator = schemaValidator;
exports.saveToDB = saveToDB;