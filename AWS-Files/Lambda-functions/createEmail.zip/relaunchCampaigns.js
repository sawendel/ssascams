const https = require('https');
const env = require("./env.js");
const mariadb = require('mariadb');

const pool = mariadb.createPool({host: env.ec2Host, user: env.DBUser, password: env.DBPassword, port:env.DBPort, database: env.DBtoConnect, connectionLimit: 5});
const hostname = env.ec2Host;
const gophishAuth = env.gophishAPIKey;

let getCampaignIDs = function(gophishGroupName) {
    var query = `SELECT campaignid from groups_per_campaign where groupname = "${gophishGroupName}"`;
    return new Promise (function (resolve, reject){
        pool.getConnection().then(conn=>{
                conn.query(query)
                .then(rows=>{
                    //console.log(rows);
                    resolve(rows);})
                .catch(e=>{reject(e)})
                .then(()=>{
                    conn.release();
                    resolve("Success");})
                }).catch(e=>{reject(e)});
    })
  }
  
  async function relaunchCampaign(campaignID, gophishGroupName){
    const path = `/api/campaigns/${campaignID.toString()}`;
    const options = {
        hostname: hostname,
        port: 3333,
        path: path,
        rejectUnauthorized: false,
        method: 'POST',
        headers: {
            Authorization: gophishAuth
        }
    };
    console.log("antes de llamar al promise del campaign ",campaignID);
    const payload = {
        "groupName": gophishGroupName
    }
      return new Promise((resolve, reject)=>{
        var req = https.request(options, function(res){
          var result = "";
          res.on('data', (chunk) => {
            result+= chunk;
          });
          res.on('end', () =>{
            resolve(JSON.parse(result));
          })
          res.on('error', (err) =>{
            reject(err);
          })
          
        });
        req.write(JSON.stringify(payload));
        req.end();
      })
  }

  async function relaunchCampaigns(gophishGroupName){
      const campaignIDs = await getCampaignIDs(gophishGroupName);
      let cont = campaignIDs.length - 1;
      while(cont>=0){
          await relaunchCampaign(campaignIDs[cont].campaignid, gophishGroupName);
          console.log("hice relaunch a ", campaignIDs[cont].campaignid)
          cont = cont - 1;
      }
      
  }
  
  exports.relaunchCampaigns = relaunchCampaigns

      
  