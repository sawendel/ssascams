const https = require('https');
const env = require("./env.js");
const mariadb = require('mariadb');
const pool = mariadb.createPool({host: "3.20.89.142", user: "testaws", password: "pass1234", port:3306, database: "vmail", connectionLimit: 5});
const hostname = '3.20.89.142';
const gophishAuth = "1511b4aa4dfcf489f1f9f7fa9c62eda74911c62f9d3a1df8a00612aae2437ddd";
let getCampaignIDs = function(gophishGroupName) {
    var query = `SELECT campaignid from groups_per_campaign where groupname = "${gophishGroupName}"`;
    return new Promise (function (resolve, reject){
        pool.getConnection().then(conn=>{
                conn.query(query)
                .then(rows=>{
                    //console.log(rows);
                    resolve(rows);})
                .catch(e=>{reject(e)})
                .then(()=>{
                    conn.release();
                    resolve("Success");})
                }).catch(e=>{reject(e)});
    })
  }
  
  async function relaunchCampaign(campaignID, gophishGroupName){
    const path = `/api/campaigns/${campaignID.toString()}`;
    const options = {
        hostname: hostname,
        port: 3333,
        path: path,
        rejectUnauthorized: false,
        method: 'POST',
        headers: {
            Authorization: gophishAuth
        }
    };
    console.log("antes de llamar al promise del campaign ",campaignID);
    const payload = {
        "groupName": gophishGroupName
    }
      return new Promise((resolve, reject)=>{
        var req = https.request(options, function(res){
          var result = "";
          res.on('data', (chunk) => {
            result+= chunk;
          });
          res.on('end', () =>{
            resolve(JSON.parse(result));
          })
          res.on('error', (err) =>{
            reject(err);
          })
          
        });
        req.write(JSON.stringify(payload));
        req.end();
      })
  }

  async function relaunchCampaigns(gophishGroupName){
      const campaignIDs = await getCampaignIDs(gophishGroupName);
      let cont = campaignIDs.length - 1;
      while(cont>=0){
          await relaunchCampaign(campaignIDs[cont].campaignid, gophishGroupName);
          console.log("hice relaunch a ", campaignIDs[cont].campaignid)
          cont = cont - 1;
      }
      
  }
  
  exports.relaunchCampaigns = relaunchCampaigns

      
  