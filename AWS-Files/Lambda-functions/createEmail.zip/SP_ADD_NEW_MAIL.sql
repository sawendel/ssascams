DROP PROCEDURE IF EXISTS sscams_registermailbox;
DELIMITER $$

CREATE PROCEDURE sscams_registermailbox
(
	pEmail VARCHAR(255),
    pFullName VARCHAR(255),
    OUT pStatus TINYINT
)
BEGIN
	-- crear un sistema de código errores 
	DECLARE SUCCEED INT DEFAULT(53000);
	DECLARE INTERNAL_FAILED INT DEFAULT(53001);
	DECLARE EMAIL_ALREADY_EXISTS INT DEFAULT(53002);

	DECLARE domainName VARCHAR(100)

	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		GET DIAGNOSTICS CONDITION 1 @err_no = MYSQL_ERRNO, @message = MESSAGE_TEXT;
        SET pStatus = @err_no;
        
        IF (ISNULL(@message)) THEN 
			SET @message = 'Problem with email creation, check error code number';            
        ELSE
            SET @message = CONCAT('Internal error: ', @message);
            SET pStatus = INTERNAL_FAILED;
        END IF;
        
        ROLLBACK;
        
        RESIGNAL SET MESSAGE_TEXT = @message;
	END;

	SET autocommit = 0;

	IF EXISTS(SELECT username FROM mailbox WHERE username=pEmail) THEN 
		SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = EMAIL_ALREADY_EXISTS;		
	END IF;

	SET domainName = TRIM(SUBSTRING(pEmail, LOCATE('@', pMail)+1));

	START TRANSACTION;
		INSERT INTO mailbox (username, password, name,
                     storagebasedirectory,storagenode, maildir,
                     quota, domain, active, passwordlastchange, created)
		SELECT pEmail, password, pFullName,
		storagebasedirectory,  storagenode, CONCAT(domainName, '/t/r/s/', UUID()),
		quota, domain, active, NOW(), NOW() FROM
		mailbox where username=CONCAT('template@', domainName);

		INSERT INTO forwardings (address, forwarding, domain, dest_domain, is_forwarding)
        VALUES (pEmail, pEmail, domainName, domainName, 1);

        SET pStatus = SUCCEED;
    COMMIT;
END$$
DELIMITER ;
