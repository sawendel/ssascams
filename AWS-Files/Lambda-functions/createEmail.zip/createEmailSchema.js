const createEmailSchema = () => (
    {
        "type": "object",
        "required": [
            "userId",
            "gophishGroupName",
            "researcherName",
            "researchName",
            "interventionId"
        ],
        "properties": {
            "userId": {
                "type": "string",
            },
            "gophishGroupName": {
                "type": "string",
            },
            "firstName": {
                "type": "string",
            },
            "lastName": {
                "type": "string",
            },
            "researcherName": {
                "type": "string",
            },
            "researchName": {
                "type": "string",
            },
            "interventionId": {
                "type": "string",
            },
        "additionalProperties": false
    }
}
);

exports.createEmailSchema = createEmailSchema;
