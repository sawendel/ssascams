const schema = require("./createEmailSchema.js");
const utils = require("./utils.js");
var MariaSingletonFactory = require('./mariadbFunctions.js')
const env = require("./env.js");
const relaunch = require("./relaunchCampaigns.js")
exports.handler = async (event) => {
    // TODO implement
    
    const isSchemaValid = utils.schemaValidator(schema.createEmailSchema(), event);
    var response = null;
    
    if (isSchemaValid){
        try {

            event.userId = event.userId.toLowerCase();
            
            var email = utils.generateEmailName(event.userId);
            await MariaSingletonFactory.getInstance().addEmailToMailServer(email, event);

            var gophish = await utils.addUserToGophishGroup(event, email);

            var URLToLogin = utils.generateMailClientURL(email);
            var bdResponse = await utils.saveToDB(event, email, URLToLogin);

            await relaunch.relaunchCampaigns(event.gophishGroupName)

            response = {
            statusCode: 200,
            body: {
                url: URLToLogin,
                emailUser: email,
                password: env.generalEmailPassword
            },
            };
            
            
        } catch (e) {
            console.log(e);
            response = {
            statusCode: 500,
            body: JSON.stringify("Could not create mail"),
            };
        }
        
    }
    else
    {
        response = {
        statusCode: 400,
        body: JSON.stringify('The request does not match the valid schema'),
        };
    }
    
    return response;
};