const logUserActionSchema = () => (
    {
        "type": "object",
        "required": [
            "userId",
            "emailId",
            "interventionId",
            "researchName",
            "researcherName",
            "event",
            "Mode"
        ],
        "properties": {
            "userId": {
                "type": "string",
            },
            "emailId": {
                "type": "string",
            },
            "interventionId": {
                "type": "string",
            },
            "researchName": {
                "type": "string",
            },
            "researcherName": {
                "type": "string",
            },
            "event": {
                "type": "string",
            },
            "Mode": {
                "type": "string",
            }
        },
        "additionalProperties": false
    }
);



exports.logUserActionSchema = logUserActionSchema;