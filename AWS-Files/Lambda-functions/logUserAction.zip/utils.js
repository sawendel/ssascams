const Ajv = require('ajv');
const ajv = new Ajv.default({ allErrors: true });

function schemaValidator(schema, data) {
  const validate = ajv.compile(schema);
  const validateData = validate(data);
  if (validateData) {
    return true;
  }
  console.log(validate.errors);
  return false;
}

function getServerDate(){
  var date = new Date();
  return date;
}

async function saveToDB(actionData){
  var AWS = require('aws-sdk');
  var ddb = new AWS.DynamoDB({region: 'us-east-2'}); 
  var serverDate = getServerDate().toString();
  var PK = actionData.userId.concat("-", actionData.emailId);
  var params = {
    TableName: 'User_Events',
    Item: {
      'USERID_MAILID': {S: PK},
      'USER_ID' : {S: actionData.userId},
      'EMAIL_ID' : {S: actionData.emailId} ,
      'INTERVENTION_ID' : {S: actionData.interventionId},
      'RESEARCH_NAME' : {S: actionData.researchName},
      'RESEARCHER_NAME' : {S: actionData.researcherName},
      'EVENT' : {S: actionData.event},
      'MODE' : {S: actionData.Mode},
      'POSTTIME' : {S: serverDate}
      }
    };
  
  return new Promise((resolve, reject) => {
        ddb.putItem(params, function(err, data) {
        if (err) {
          console.log(err);
          reject(err);
        } else {
          resolve (true);
        }
      });
    });
}

exports.getServerDate = getServerDate;
exports.schemaValidator = schemaValidator;
exports.saveToDB = saveToDB;