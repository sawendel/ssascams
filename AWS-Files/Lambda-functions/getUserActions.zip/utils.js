
const Ajv = require('ajv');
var AWS = require('aws-sdk');
const ajv = new Ajv.default({ allErrors: true });
const ObjectsToCsv = require('objects-to-csv');

function schemaValidator(schema, data) {
  const validate = ajv.compile(schema);
  const validateData = validate(data);
  if (validateData) {
    return true;
  }
  console.log(validate.errors);
  return validate.errors;
}

async function getFromDBByResearch(researchName){
 // Load the AWS SDK for Node.js
  var AWS = require('aws-sdk');
  var ddb = new AWS.DynamoDB({region: 'us-east-2'});
  var params = {
  ExpressionAttributeValues: {
    ':researchName' : {S: researchName}
  },
  FilterExpression: 'RESEARCH_NAME = :researchName',
  ProjectionExpression: 'USER_ID, EMAIL_ID, POSTTIME, EVENT, INTERVENTION_ID,RESEARCHER_NAME, RESEARCH_NAME',
  TableName: 'User_Events'
};
  
  // Call DynamoDB to read the item from the table
  return new Promise((resolve, reject)=>{
    ddb.scan(params, function(err, data) {
    if (err) {
      reject(err)
    } else {
      resolve(data.Items);
      
    }
  });
  })
}

async function getFromDBByEmail(EmailID){
 // Load the AWS SDK for Node.js
  var AWS = require('aws-sdk');
  var ddb = new AWS.DynamoDB({region: 'us-east-2'});
  var params = {
  ExpressionAttributeValues: {
    ':emailID' : {S: EmailID}
  },
  FilterExpression: 'EMAIL_ID = :emailID',
  ProjectionExpression: 'USER_ID, EMAIL_ID, POSTTIME, EVENT, INTERVENTION_ID,RESEARCHER_NAME, RESEARCH_NAME',
  TableName: 'User_Events'
};
  
  // Call DynamoDB to read the item from the table
  return new Promise((resolve, reject)=>{
    ddb.scan(params, function(err, data) {
    if (err) {
      reject(err)
    } else {
      resolve(data.Items);
      
    }
  });
  })
}




async function getAllRecordsBD(){
  // Load the AWS SDK for Node.js
  var AWS = require('aws-sdk');
  var ddb = new AWS.DynamoDB({region: 'us-east-2'});
  var params = {
  ProjectionExpression: 'USER_ID, EMAIL_ID, POSTTIME, EVENT, INTERVENTION_ID,RESEARCHER_NAME, RESEARCH_NAME',
  TableName: 'User_Events'
  };
  
  // Call DynamoDB to read the item from the table
  return new Promise((resolve, reject)=>{
    ddb.scan(params, function(err, data) {
    if (err) {
      reject(err)
    } else {

      resolve(data.Items);
      
    }
  });
  })
}

function filterByResearchName(jsonData, researchName){
  var result = [];
  jsonData.forEach((element)=>{
    if(element.researchName == researchName){
      result.push(element);
    }
  })
  return result;
}

function filterByEmailID(jsonData, emailID){
  var result = [];
  jsonData.forEach((element)=>{
    if(element.emailID == emailID){
      result.push(element);
    }
  })
  return result;
}

function filterByDate(jsonData,dateFrom, dateTo){
  dateFrom = new Date(dateFrom);
  dateTo = new Date(dateTo);
  var result = [];
  jsonData.forEach((element)=>{
    var currentDate = new Date(element.posttime);
    if((dateFrom.getFullYear()<=currentDate.getFullYear()) && (currentDate.getFullYear() <=dateTo.getFullYear()) && 
    (dateFrom.getMonth()<=currentDate.getMonth()) && (currentDate.getMonth()<=dateTo.getMonth()) && 
    (dateFrom.getDate()<=currentDate.getDate()) && (currentDate.getDate()<=dateTo.getDate())){
      result.push(element);
    }
  })
  return result;
}

function parseDynamoDataToJson(items){
  let cont = items.length - 1;
  let result = [];
  var item;
  while(cont>=0){
    item = {
      "userID":items[cont].USER_ID.S,
      "emailID":items[cont].EMAIL_ID.S,
      "posttime":items[cont].POSTTIME.S,
      "event":items[cont].EVENT.S,
      "interventionID":items[cont].INTERVENTION_ID.S,
      "researchName":items[cont].RESEARCH_NAME.S,
      "researcherName":items[cont].RESEARCHER_NAME.S
    }
    result.push(item);
    cont = cont - 1;
  }
  return result
}

async function jsonToCSV(json){
  const csv = new ObjectsToCsv(json);
  var csvAsString = await csv.toString()
  return csvAsString;
}

async function uploadToS3(csv) {
  let s3bucket = new AWS.S3();
    var params = {
    Bucket: 'sscams',
    Key:`${Date.now()}-User-Events.csv`,
    Body: csv,
    ACL: 'public-read',
    ContentType: 'text/csv'
  };
  var data = await s3bucket.upload(params, function (err, data) {
    if (err) {
      console.log('error in callback');
      console.log(err);
    }
    console.log('success');
    console.log(data.Location);
  }).promise();
  return data.Location;
}




exports.filterByEmailID = filterByEmailID
exports.filterByResearchName = filterByResearchName

exports.getFromDBByEmail = getFromDBByEmail;
exports.uploadToS3 = uploadToS3;
exports.jsonToCSV = jsonToCSV;
exports.parseDynamoDataToJson = parseDynamoDataToJson;
exports.schemaValidator = schemaValidator;
exports.getFromDBByResearch = getFromDBByResearch;
exports.filterByDate = filterByDate;
exports.getAllRecordsBD = getAllRecordsBD;