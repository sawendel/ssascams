const getEmailUserInfoSchema = () => (
    {
        "type": "object",
        "required": [
        ],
        "properties": {
            "ResearchName": {
                "type": "string",
                "minLength": 1
            },
            "DateFrom": {
                "type": "string",
                "minLength": 1
            },
            "DateTo": {
                "type": "string",
                "minLength": 1
            },
            "EmailId":{
                "type": "string",
                "minLength": 1
            }
        },
        "additionalProperties": false
    }
);




exports.getEmailUserInfoSchema = getEmailUserInfoSchema;