const schema = require("./getEmailUserInfoSchema.js");
const utils = require("./utils.js");

exports.handler = async (event) => {
    // TODO implement
    
    const isSchemaValid = utils.schemaValidator(schema.getEmailUserInfoSchema(), event);
    var response = null;
    
    if (isSchemaValid == true){
        try {
            var bdTransaction = await utils.getAllRecordsBD();;
            var json = utils.parseDynamoDataToJson(bdTransaction);
            if(event.hasOwnProperty("ResearchName")){
                json = utils.filterByResearchName(json, event.ResearchName);
            }
            if(event.hasOwnProperty("EmailId")){
                json = utils.filterByEmailID(json, event.EmailId);
            }
            if(event.hasOwnProperty("DateFrom") && event.hasOwnProperty("DateTo")){
                json = utils.filterByDate(json, event.DateFrom, event.DateTo);
            }
            // switch (event.FilterBy) {
            //     case 'Research Name':
            //         bdTransaction = await utils.getFromDBByResearch(event.ResearchName);
            //         json = utils.parseDynamoDataToJson(bdTransaction);
            //         if(event.DateFrom!="" && event.DateTo!=""){
            //             json = utils.filterByDate(json, event.DateFrom, event.DateTo);
            //         }
            //         break;
            //     case 'Email ID':
            //         bdTransaction = await utils.getFromDBByEmail(event.Email_id);
            //         json = utils.parseDynamoDataToJson(bdTransaction);
            //         if(event.DateFrom!="" && event.DateTo!=""){
            //             json = utils.filterByDate(json, event.DateFrom, event.DateTo);
            //         }
            //         break;
            //     default:
            //         bdTransaction = await utils.getAllRecordsBD();
            //         json = utils.parseDynamoDataToJson(bdTransaction);
            //         json = utils.filterByDate(json, event.DateFrom, event.DateTo);
            // }
            
            
            var csv = await utils.jsonToCSV(json);
            var csvURL = await utils.uploadToS3(csv);
    
            response = {
            statusCode: 200,
            body: csvURL,
            };
        } catch (e) {
            console.log(e);
            response = {
            statusCode: 500,
            body: "The data could not be retrieved",
            };
        }
        
    }
    else
    {
        response = {
        statusCode: 400,
        body: isSchemaValid,
        };
    }
    
    return response;
};
