const Ajv = require('ajv');
const ajv = new Ajv.default({ allErrors: true });

function schemaValidator(schema, data) {
  const validate = ajv.compile(schema);
  const validateData = validate(data);
  if (validateData) {
    return true;
  }
  //console.log(validate.errors);
  return false;
}

function getServerDate(){
  var date = new Date();
  return date;
}



async function saveToDB(surveyData){
  var AWS = require('aws-sdk');
  var ddb = new AWS.DynamoDB({region: 'us-east-2'}); 
  var serverDate = getServerDate().toString();
  var params = {
    TableName: 'Survey_Answers',
    Item: {
      'USER_ID' : {S: surveyData.userId},
      'SURVEY_SESSION_ID' : {S: surveyData.surveySessionId} ,
      'QUESTION_NUMBER' : {N: surveyData.questionNumber.toString()},
      'QUESTION_CAPTION' : {S: surveyData.questionCaption},
      'ANSWER_VALUE' : {S: surveyData.answerValue},
      'ANSWER' : {S: surveyData.answer},
      'POSTTIME' : {S: serverDate}
      }
    };
  
  return new Promise((resolve, reject) => {
        ddb.putItem(params, function(err, data) {
        if (err) {
          reject(err);
        } else {
          resolve (true);
        }
      });
    });
}

exports.getServerDate = getServerDate;
exports.schemaValidator = schemaValidator;
exports.saveToDB = saveToDB;