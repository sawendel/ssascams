const schema = require("./surveyAnswerLogSchema.js");
const utils = require("./utils.js");
exports.handler = async (event) => {
    // TODO implement
    
    const isSchemaValid = utils.schemaValidator(schema.surveyAnswerLogSchema(), event);
    var response = null;

    if (isSchemaValid){
        try {
            var bdTransaction = await utils.saveToDB(event);
            response = {
            statusCode: 200,
            body: JSON.stringify('Survey answer logged successfully'),
            };
        } catch (e) {
            response = {
            statusCode: 500,
            body: JSON.stringify('Data could not be saved'),
            };
        }
        
    }
    else
    {
        response = {
        statusCode: 400,
        body: JSON.stringify('The request does not match the valid schema'),
        };
    }
    
    return response;
};
