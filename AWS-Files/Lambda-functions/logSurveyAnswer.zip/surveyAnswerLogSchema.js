const surveyAnswerLogSchema = () => (
    {
        "type": "object",
        "required": [
            "userId",
            "surveySessionId",
            "questionNumber",
            "questionCaption",
            "answerValue",
            "answer"
        ],
        "properties": {
            "userId": {
                "type": "string",
            },
            "surveySessionId": {
                "type": "string",
            },
            "questionNumber": {
                "type": "integer",
            },
            "questionCaption": {
                "type": "string",
            },
            "answerValue": {
                "type": "string",
            },
            "answer": {
                "type": "string",
            }
        },
        "additionalProperties": false
    }
);
 exports.surveyAnswerLogSchema = surveyAnswerLogSchema;