const mariadb = require('mariadb');
var _pool;

var MariaSingletonFactory = function() {

  return {
    getInstance: function() {
      if (_pool == null) {
          _pool = mariadb.createPool({host: "3.20.89.142", user: "testaws", password: "pass1234", port:3306, database: "vmail", connectionLimit: 1});
      }
      return this;
    },
    
    addEmailToMailServer : async function(email, emailData) {
        var name = " "
        if(emailData.hasOwnProperty("firstName")){
              name = emailData.firstName;
        }else{
          name = emailData.userId;
        }
        let conn;
        var result = 0;
        try {
          conn = await _pool.getConnection();
          
         await conn.query(`CALL sscams_registermailbox("${email}","${name}");`);
        } catch (err) {
        throw err;
        } finally {
        if (conn) conn.release(); //release to pool
        }
    },
      
    getCampaignIDs : async function(gophishGroupName) {
        let conn;
        var result = 0;
        var query = `SELECT campaignid from groups_per_campaign where groupname = "${gophishGroupName}"`;
        console.log(query);
        try {
          conn = await _pool.getConnection();
          
         await conn.query(query).then((rows)=>{
           return rows;
         });
        } catch (err) {
        throw err;
        } finally {
        if (conn) conn.release(); //release to pool
        }
    },
    
    getCampaignIDs : async function(gophishGroupName) {
      var conn;
        var query = `SELECT campaignid from groups_per_campaign where groupname = "${gophishGroupName}"`;
        return new Promise (function (resolve, reject){
            _pool.getConnection().then(conn=>{
                    conn.query(query)
                    .then(rows=>{
                        //console.log(rows);
                        conn.release();
                        resolve(rows);})
                    .catch(e=>{
                      conn.release();
                      reject(e)})
                    .then(()=>{
                        conn.release();
                        resolve("Success");})
                    }).catch(e=>{
                      conn.release();
                      reject(e)});
        })
    },
        
      registerlunchmailgroup : async function(gophishGroupName) {
        var conn;
      try 
      {
        conn = await _pool.getConnection();
        await conn.query(`CALL lunchmailgroup("${gophishGroupName}");`);
      } 
      catch (err) 
      {
        throw err;
      } 
      finally 
      {
        if (conn) 
          conn.release(); //release to pool
      }
    },
    
    checkgroupstosend : async function() {
      var conn;
      return new Promise (function (resolve, reject){
          _pool.getConnection().then(conn=>{
                  conn.query(`CALL checkgroupstosend();`)
                  .then(rows=>{
                      conn.release();
                      resolve(rows);})
                  .catch(e=>{
                    conn.release();
                    reject(e)})
                  .then(()=>{
                      conn.release();
                      resolve("Success");})
                  }).catch(e=>{
                    conn.release();
                    reject(e)});
      })
    }  
  }
}

module.exports = MariaSingletonFactory();