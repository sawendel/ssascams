const https = require('https');
const env = require("./env.js");
var MariaSingletonFactory = require('./mariadbFunctions.js')
//const mariadb = require('mariadb');
//const pool = mariadb.createPool({host: "3.20.89.142", user: "testaws", password: "pass1234", port:3306, database: "vmail", connectionLimit: 5});
const hostname = '3.20.89.142';
const gophishAuth = "bca4b0217e5668979d685720028c6675ee62105683c0b9f010bf8084aa2d1eab";

  
  async function relaunchCampaign(campaignID, gophishGroupName){
    const path = `/api/campaigns/${campaignID.toString()}`;
    const options = {
        hostname: hostname,
        port: 3333,
        path: path,
        rejectUnauthorized: false,
        method: 'POST',
        headers: {
            Authorization: gophishAuth
        }
    };
    console.log("antes de llamar al promise del campaign ",campaignID);
    const payload = {
        "groupName": gophishGroupName
    }
      return new Promise((resolve, reject)=>{
        var req = https.request(options, function(res){
          var result = "";
          res.on('data', (chunk) => {
            result+= chunk;
          });
          res.on('end', () =>{
            resolve(JSON.parse(result));
          })
          res.on('error', (err) =>{
            reject(err);
          })
          
        });
        req.write(JSON.stringify(payload));
        req.end();
      })
  }

  async function relaunchCampaigns(gophishGroupName){
      const campaignIDs = await MariaSingletonFactory.getInstance().getCampaignIDs(gophishGroupName);
      let cont = campaignIDs.length - 1;
      while(cont>=0){
          await relaunchCampaign(campaignIDs[cont].campaignid, gophishGroupName);
          console.log("hice relaunch a ", campaignIDs[cont].campaignid)
          cont = cont - 1;
      }
      
  }
  
  exports.relaunchCampaigns = relaunchCampaigns;
exports.relaunchCampaign = relaunchCampaign;