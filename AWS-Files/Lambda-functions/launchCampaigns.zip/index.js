const schema = require("./createEmailSchema.js");
const utils = require("./utils.js");
var MariaSingletonFactory = require('./mariadbFunctions.js')
const env = require("./env.js");
const relaunch = require("./relaunchCampaigns.js")

exports.handler = async (event) => {
    var response = null;
    
    try 
    {
        var campaignIDs = await MariaSingletonFactory.getInstance().checkgroupstosend();
        campaignIDs = campaignIDs[0];
        let cont = campaignIDs.length - 1;
        
        while(cont>=0){
              await relaunch.relaunchCampaign(campaignIDs[cont].campaignid, campaignIDs[cont].groupname);
              cont = cont - 1;
        } 
  
        response = {
            statusCode: 200,
            body: {
                groups: []
            },
        };    
    }  
    catch (e) 
    {
        console.log(e);
        response = {
            statusCode: 500,
            body: JSON.stringify("Could not create mail"),
        }
    }    
    return response;
};
