
const Ajv = require('ajv');
const ajv = new Ajv.default({ allErrors: true });

function schemaValidator(schema, data) {
  const validate = ajv.compile(schema);
  const validateData = validate(data);
  if (validateData) {
    return true;
  }
  console.log(validate.errors);
  return validate.errors;
}

async function getFromDB(email){
 // Load the AWS SDK for Node.js
  var AWS = require('aws-sdk');
  var ddb = new AWS.DynamoDB({region: 'us-east-2'});
  var params = {
  ExpressionAttributeValues: {
    ':emaiToSearch' : {S: email}
  },
  FilterExpression: 'EMAIL = :emaiToSearch',
  ProjectionExpression: 'USER_ID, EMAIL, INTERVENTION_ID, RESEARCHER_NAME, RESEARCH_NAME',
  TableName: 'Emails'
};
  
  // Call DynamoDB to read the item from the table
  return new Promise((resolve, reject)=>{
    ddb.scan(params, function(err, data) {
    if (err) {
      reject(err)
    } else {
      var jsonToReturn = {
        "userID": data.Items[0].USER_ID.S,
        "email": data.Items[0].EMAIL.S,
        "interventionID": data.Items[0].INTERVENTION_ID.S,
        "researcherName": data.Items[0].RESEARCHER_NAME.S,
        "researchName": data.Items[0].RESEARCH_NAME.S
      };
      console.log(data.Items);
      resolve(jsonToReturn);
      
    }
  });
  })
}

exports.schemaValidator = schemaValidator;
exports.getFromDB = getFromDB;