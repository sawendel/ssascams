
const Ajv = require('ajv');
const ajv = new Ajv.default({ allErrors: true });

function schemaValidator(schema, data) {
  const validate = ajv.compile(schema);
  const validateData = validate(data);
  if (validateData) {
    return true;
  }
  console.log(validate.errors);
  return validate.errors;
}

async function getFromDB(email){
  const AWS = require('aws-sdk');
  AWS.config.update({ region: 'us-east-2' });
  var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

  const arrobaposition = email.search('@');
  const userid = email.substring(0, arrobaposition);

  var params = {
    KeyConditionExpression: 'USER_ID = :userid',
    FilterExpression: 'EMAIL = :emailtosearch',
    ExpressionAttributeValues: {
      ':userid' : {'S': userid},
      ':emailtosearch' :  {'S' : email}
    },
    TableName: 'Emails',
  };

  var data = await dynamodb.query(params).promise();
  
  if (data.Items && data.Items[0]) {
      var jsonToReturn = {
        "userID": data.Items[0].USER_ID.S,
        "email": data.Items[0].EMAIL.S,
        "interventionID": data.Items[0].INTERVENTION_ID.S,
        "researcherName": data.Items[0].RESEARCHER_NAME.S,
        "researchName": data.Items[0].RESEARCH_NAME.S
      };
      
      return jsonToReturn;    
  } else {
    throw "The data could not be retrieved";
  }
}


exports.schemaValidator = schemaValidator;
exports.getFromDB = getFromDB;