const schema = require("./getEmailUserInfoSchema.js");
const utils = require("./utils.js");

exports.handler = async (event) => {
    // TODO implement
    
    const isSchemaValid = utils.schemaValidator(schema.getEmailUserInfoSchema(), event);
    var response = null;
    
    if (isSchemaValid == true){
        try {
            var bdTransaction = await utils.getFromDB(event.Email);
            response = {
            statusCode: 200,
            body: bdTransaction,
            };
        } catch (e) {
            console.log(e);
            response = {
            statusCode: 500,
            body: "The data could not be retrieved",
            };
        }
        
    }
    else
    {
        response = {
        statusCode: 400,
        body: isSchemaValid,
        };
    }
    
    return response;
};
