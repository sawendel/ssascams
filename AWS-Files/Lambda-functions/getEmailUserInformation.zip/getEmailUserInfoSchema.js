const getEmailUserInfoSchema = () => (
    {
        "type": "object",
        "required": [
            "Email"
        ],
        "properties": {
            "Email": {
                "type": "string",
            }
        },
        "additionalProperties": false
    }
);


exports.getEmailUserInfoSchema = getEmailUserInfoSchema;